<?php

require_once "conexion.php";
require_once "clasepdf.php";
require "phpqrcode/qrlib.php";

$objetoconexion=new Conexion();
$conex=$objetoconexion->conectar();

$sql="select * from productos";

$stmt=$conex->prepare($sql);

$stmt->execute();

$result=$stmt->get_result();

if($result->num_rows>0){
    $pdf=new PDF();

    $pdf->AddPage();

    $pdf->SetFont('Arial','',14);

    while($fila=$result->fetch_assoc()){
        $nombreArchivo="qr".$fila["idProducto"].".png";
        $contenido="http://localhost/Practica_profesionalizante_II/verIdentificadorProducto.php?=".$fila["idProducto"];
        $ruta="codigosQR/".$nombreArchivo;
        QRcode::png($contenido, $ruta, "L", 32, 5);
        $sql2="UPDATE productos set nombreimagenqr=? WHERE idProducto=?";
        $stmt2=$conex->prepare($sql2);
        $stmt2->bind_param("si", $nombreArchivo, $fila["idProducto"]);
        $stmt2->execute();

        $pdf->Cell(15);
        $pdf->cell(70,20,$fila["nombre"],1,0,"C");
        $pdf->cell(40,20,$fila["precio"],1,0,"C");
        $pdf->cell(15,20,$fila["existencia"],1,0,"C");
        
        $y=$pdf->GetY();
        $x=$pdf->GetX();

        $pdf->cell(20, 20, "", 1, 1);
        $pdf->Image($ruta, $x+2, $y+2, 15);
        }
        $pdf->output("i", "listadoproductos.pdf");
    }



?>