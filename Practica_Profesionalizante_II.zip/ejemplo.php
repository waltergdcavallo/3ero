<?php

class ejemplo{
    public $dni;
    public $nombre;
    public $apellido;
    public $email;

    }
    public function saludar(){
        echo .$this->$dni;
        echo .$this->$nombre;
        echo .$this->$apellido;
        echo .$this->$email;
    }

?>