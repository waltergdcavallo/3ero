-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 24-10-2023 a las 18:08:34
-- Versión del servidor: 10.4.22-MariaDB
-- Versión de PHP: 8.0.13

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `abdespensa`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `categoria`
--

CREATE TABLE `categoria` (
  `id` int(11) NOT NULL,
  `nombre` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `categoria`
--

INSERT INTO `categoria` (`id`, `nombre`) VALUES
(1, 'Refrescos'),
(2, 'Aceites'),
(3, 'Detergentes'),
(4, 'Dulces'),
(5, 'Frituras'),
(10, 'Enlatados'),
(11, 'Cereales');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `detalle_producto_proveedor`
--

CREATE TABLE `detalle_producto_proveedor` (
  `id` int(11) NOT NULL,
  `idProducto` int(11) NOT NULL,
  `idProveedor` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `detalle_producto_proveedor`
--

INSERT INTO `detalle_producto_proveedor` (`id`, `idProducto`, `idProveedor`) VALUES
(1, 1, 1),
(2, 2, 1),
(4, 4, 2),
(5, 5, 1),
(6, 6, 4),
(7, 7, 3),
(8, 8, 5),
(9, 9, 6),
(10, 10, 5),
(11, 11, 5),
(12, 12, 6),
(13, 13, 8),
(14, 14, 7),
(16, 16, 8),
(18, 18, 9),
(19, 19, 10),
(20, 20, 10),
(21, 21, 9),
(22, 6, 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `productos`
--

CREATE TABLE `productos` (
  `idProducto` int(11) NOT NULL,
  `nombre` varchar(100) NOT NULL,
  `precio` decimal(10,2) NOT NULL,
  `fecha_alta` date DEFAULT '0000-00-00',
  `idCategoria` int(11) NOT NULL,
  `existencia` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `productos`
--

INSERT INTO `productos` (`idProducto`, `nombre`, `precio`, `fecha_alta`, `idCategoria`, `existencia`) VALUES
(1, 'Refresco de Yerba Mate', '10.00', '2016-01-01', 1, 10),
(2, 'Refesco de Lima', '9.00', '2015-02-06', 1, 15),
(4, 'Refresco de Uva', '9.00', '2016-05-07', 1, 20),
(5, 'Agua Mineral', '15.00', '2016-02-15', 1, 8),
(6, 'Aceite Natural 1 Litro', '20.00', '2015-09-20', 2, 25),
(7, 'Aceite de Coco 500 ml', '15.00', '2016-03-24', 2, 20),
(8, 'Jabon lavanda 1 kg', '12.00', '2014-02-21', 3, 6),
(9, 'Detergente en polvo 1 kg', '18.50', '2014-11-17', 3, 9),
(10, 'Jabon para manos 500 ml', '26.50', '2016-01-10', 3, 7),
(11, 'Detergente en polvo 2 kg', '30.00', '2014-11-17', 3, 5),
(12, 'Detergente en polvo 500 g', '18.50', '2016-02-20', 3, 8),
(13, 'Paleta de caramelo', '5.00', '2013-01-01', 4, 50),
(14, 'Paleta de chocolate', '6.50', '2014-05-20', 4, 34),
(16, 'Bolsa de dulces variados', '14.50', '2015-12-12', 4, 23),
(18, 'Frituras de queso', '18.00', '2014-10-09', 5, 12),
(19, 'Papas Fritas con limon', '10.00', '2015-09-08', 5, 8),
(20, 'Bolsa de chicharrones', '15.00', '2016-05-20', 5, 19),
(21, 'Palomitas de mantequilla', '18.00', '2015-11-28', 5, 12),
(25, 'Alfajores Merengo', '250.00', '2019-05-26', 4, 50),
(26, 'Alfajores NorteÃ±os', '35.00', '2019-05-27', 4, 70),
(27, 'Alfajor Merengo', '50.00', '2019-05-26', 4, 150),
(28, 'Alfajor Havanna', '100.00', '2019-05-27', 4, 100),
(29, 'Chocolate Milka', '70.00', '2019-05-26', 4, 150),
(30, 'Chocolate Tofi', '35.00', '2019-05-27', 4, 60),
(31, 'Huevo Kinder', '55.00', '2019-05-26', 4, 150),
(32, 'Turron de Mani Arcor', '25.00', '2019-05-27', 4, 120),
(33, 'Mantecol Georgalos', '50.00', '2019-05-26', 4, 150),
(34, 'Barra de Cereal CerealMix', '35.00', '2019-05-27', 4, 80),
(35, 'Pastilla de Menta Tic Tac', '30.00', '2019-05-26', 4, 50),
(36, 'Pastilla de Cereza Mentoliptus', '25.00', '2019-05-27', 4, 70),
(37, 'Chicle Adams', '25.00', '2019-05-26', 4, 50),
(38, 'Chicle Glub Relleno', '15.00', '2019-05-27', 4, 70),
(39, 'Kinder Sorpresa', '60.00', '2019-05-26', 4, 150),
(40, 'Kinder Joy', '65.00', '2019-05-27', 4, 170),
(41, 'Chocolate Toffler', '80.00', '2019-05-26', 4, 150),
(42, 'Chocolate Felfort', '75.00', '2019-05-27', 4, 60),
(43, 'Chocolate KitKat', '50.00', '2019-05-26', 4, 150),
(44, 'ChupetÃ­n Pico Dulce', '15.00', '2019-05-27', 4, 120),
(45, 'Bananita Dolca', '45.00', '2019-05-26', 4, 150),
(46, 'Cabsha', '55.00', '2019-05-27', 4, 80),
(47, 'Galletita Tita', '30.00', '2019-05-26', 4, 50),
(48, 'Galletita Rodhesia', '45.00', '2019-05-27', 4, 70),
(49, 'Galletitas Manon', '35.00', '2019-05-26', 4, 50),
(50, 'Chicle Bazooka', '10.00', '2019-05-27', 4, 70);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `proveedores`
--

CREATE TABLE `proveedores` (
  `id` int(11) NOT NULL,
  `nombre` varchar(45) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `proveedores`
--

INSERT INTO `proveedores` (`id`, `nombre`) VALUES
(1, 'Refrescante'),
(2, 'Refrescos SA de CV'),
(3, 'Naturalite'),
(4, 'Campullo'),
(5, 'Grupo cambay'),
(6, 'Detergentes de Mexico'),
(7, 'Sonrisas'),
(8, 'Ricodulce'),
(9, 'Bartel'),
(10, 'Frituras de Monterrey');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `categoria`
--
ALTER TABLE `categoria`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `detalle_producto_proveedor`
--
ALTER TABLE `detalle_producto_proveedor`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_prov_idx` (`idProveedor`),
  ADD KEY `fk_prod_idx` (`idProducto`);

--
-- Indices de la tabla `productos`
--
ALTER TABLE `productos`
  ADD PRIMARY KEY (`idProducto`),
  ADD UNIQUE KEY `nombre` (`nombre`),
  ADD KEY `fk_CatPro_idx` (`idCategoria`);

--
-- Indices de la tabla `proveedores`
--
ALTER TABLE `proveedores`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `categoria`
--
ALTER TABLE `categoria`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT de la tabla `detalle_producto_proveedor`
--
ALTER TABLE `detalle_producto_proveedor`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT de la tabla `productos`
--
ALTER TABLE `productos`
  MODIFY `idProducto` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=51;

--
-- AUTO_INCREMENT de la tabla `proveedores`
--
ALTER TABLE `proveedores`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `detalle_producto_proveedor`
--
ALTER TABLE `detalle_producto_proveedor`
  ADD CONSTRAINT `fk_prov` FOREIGN KEY (`idProveedor`) REFERENCES `proveedores` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `productos`
--
ALTER TABLE `productos`
  ADD CONSTRAINT `productos_ibfk_1` FOREIGN KEY (`idCategoria`) REFERENCES `categoria` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
