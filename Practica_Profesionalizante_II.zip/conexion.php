<?php

class Conexion{
    private $host="localhost";
    private $usuario="root";
    private $clave="";
    private $bd="abdespensa";
    public $conex;


    public function conectar(){
    $this->conex=new mysqli($this->host,$this->usuario, $this->clave, $this->bd);

        if ($this->conex->connect_error){
        die("error en la conexion a la base de datos");
        }
        return $this->conex;
    }
}

?>