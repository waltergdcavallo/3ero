<?php 

require_once "fpdf/fpdf.php";

class PDF extends fpdf{
    
    public function header(){
    // Logo
    $this->Image('imagenes/LogoENS40.jpg',170,8,10);
    // Arial bold 15
    $this->SetFont('Arial','B',15);
    // Movernos a la derecha
    $this->Cell(60);
    // Título
    $this->Cell(70,7,'Listado de productos',0,0,'C');
    // Salto de línea
    $this->Ln(20);
    }

    public function footer(){
        $this->SetY(-15);
        $this->SetFont('Arial', '', 12);
        $this->Cell(0, 10, 'Pagina '.$this->PageNo().'/{nb}', 0, 1, 'C');
    }
}
?>